@extends('frontend.layouts.main')


@section('main-container')

    <main id="mxd-page-content" class="mxd-page-content inner-page-content">
<div >

   <div class="text-center" style="margin-top: 100px; height:100vh;">

  
<h1 class="">Refund And Cancilation Policy</h1>



   </div>
   </div>
</main>
   @endsection
